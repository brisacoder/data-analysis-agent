# LLM Python Runner (Node + Pyodide)

This project lets you run LLM-generated Python code securely using [Pyodide](https://pyodide.org/) in Node.js.

## 🚀 Quick Start

```bash
npm install
node server.js
```

Visit: [http://localhost:3000](http://localhost:3000)

## 🧪 Example CURL Usage

### Run code with file

```bash
curl -X POST http://localhost:3000/run \
  -F "code=import pandas as pd\ndf = pd.read_csv('sample.csv')\nprint(df.head())" \
  -F "files=@sample.csv"
```

### Run code only

```bash
curl -X POST http://localhost:3000/run \
  -F "code=print('hello from pyodide')"
```
