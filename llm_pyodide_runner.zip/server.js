import express from "express";
import multer from "multer";
import { loadPyodide } from "@pyodide/pyodide";
import fs from "fs/promises";
import path from "path";

const app = express();
const upload = multer({ dest: "uploads/" });

let pyodide = null;
console.log("⏳ Loading Pyodide...");
pyodide = await loadPyodide({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.24.1/full/" });
console.log("✅ Pyodide ready.");

app.use(express.static("public"));

app.post("/run", upload.array("files"), async (req, res) => {
  try {
    const code = req.body.code;
    for (const file of req.files) {
      const data = await fs.readFile(file.path);
      pyodide.FS.writeFile("/home/pyodide/" + file.originalname, data);
    }

    const result = pyodide.runPython(code);
    res.json({ stdout: result });
  } catch (err) {
    res.json({ stderr: err.toString() });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("🌐 Server running at http://localhost:" + PORT));
